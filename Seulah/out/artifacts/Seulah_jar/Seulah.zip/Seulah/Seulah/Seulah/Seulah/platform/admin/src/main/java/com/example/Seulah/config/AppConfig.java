package com.example.Seulah.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class AppConfig {

//    @Bean
//    public rb_Eligibility1_questions eligibility1QuestionsBean() {
//        // Create and configure an instance of rb_Eligibility1_questions here
//        rb_Eligibility1_questions eligibility1Questions = new rb_Eligibility1_questions();
//
//        return eligibility1Questions;
//    }
}
