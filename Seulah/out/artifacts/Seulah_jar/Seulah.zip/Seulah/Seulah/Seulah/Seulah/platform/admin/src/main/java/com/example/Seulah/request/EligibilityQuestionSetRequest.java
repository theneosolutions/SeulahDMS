package com.example.Seulah.request;

import lombok.*;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString
public class EligibilityQuestionSetRequest {
    private String name;
}
