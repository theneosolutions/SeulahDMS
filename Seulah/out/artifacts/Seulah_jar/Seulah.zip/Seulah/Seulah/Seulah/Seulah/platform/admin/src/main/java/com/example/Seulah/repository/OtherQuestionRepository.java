package com.example.Seulah.repository;

import com.example.Seulah.entity.OtherQuestion;
import org.springframework.data.jpa.repository.JpaRepository;

public interface OtherQuestionRepository extends JpaRepository<OtherQuestion,Long> {
}
