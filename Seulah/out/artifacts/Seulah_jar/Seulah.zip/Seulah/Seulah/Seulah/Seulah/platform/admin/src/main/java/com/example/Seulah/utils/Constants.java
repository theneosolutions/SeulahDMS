package com.example.Seulah.utils;

public class Constants {

}
