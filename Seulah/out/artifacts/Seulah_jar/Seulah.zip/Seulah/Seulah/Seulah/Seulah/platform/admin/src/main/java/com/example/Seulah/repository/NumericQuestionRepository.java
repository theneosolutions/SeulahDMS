package com.example.Seulah.repository;

import com.example.Seulah.entity.NumericQuestion;
import org.springframework.data.jpa.repository.JpaRepository;

public interface NumericQuestionRepository extends JpaRepository<NumericQuestion,Long> {
}
